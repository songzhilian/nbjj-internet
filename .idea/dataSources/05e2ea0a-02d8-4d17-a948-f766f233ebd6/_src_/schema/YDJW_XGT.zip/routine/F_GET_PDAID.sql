CREATE function f_get_pdaid(v_bmdm in varchar2) return varchar2 is
  Result varchar2(16);
begin
    select substr(v_bmdm,1,6)||lpad(seq_pda_info.nextval,9,'0') into Result from dual;

  return(Result);
end f_get_pdaid;

/
