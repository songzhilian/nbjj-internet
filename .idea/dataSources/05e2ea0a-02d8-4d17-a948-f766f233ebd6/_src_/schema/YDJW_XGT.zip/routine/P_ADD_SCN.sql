CREATE procedure p_add_scn(max_scn in number)  is
   i      number;
   v_scn  number;
   begin
     for i in 1..1000 loop
       for j in 1..1000 loop
         select current_scn into v_scn from v$database;
       end loop;
     end loop;
end p_add_scn;

/
