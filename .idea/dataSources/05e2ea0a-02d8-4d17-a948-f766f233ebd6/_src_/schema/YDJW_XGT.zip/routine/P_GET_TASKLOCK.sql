CREATE procedure p_get_tasklock(vTaskId in varchar2, Result out varchar2)  is

   s_lock         varchar2(1);
   s_taskid       varchar2(32);
   s_lastrunnode  varchar2(64);
   l_taskinterval number;
   l_runinterval  number;
   d_lastruntime  date;

   begin
     Result:='false';
     begin
       s_taskid:=vTaskId;
       s_lastrunnode:='';
       if instr(vTaskid,'@')>0 then
         s_taskid:=substr(vTaskid,1,instr(vTaskid,'@')-1);
         s_lastrunnode:=substr(vTaskid,instr(vTaskid,'@')+1);
       end if;
       select lockzt,interval,lastruntime into s_lock,l_taskinterval,d_lastruntime from sys_task where taskid=vTaskId for update;

       if s_lock='0' then--锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷,锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
         update sys_task set lockzt='1',lastrunnode=s_lastrunnode,lastruntime=sysdate where taskid=s_taskid;
         Result:= 'true';
       else
         Result:='false';
         --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
         if d_lastruntime is not null then
           l_runinterval:= (sysdate-d_lastruntime)*24*60*60;--锟斤拷
           --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷1锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷1锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷1锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
           if (l_taskinterval<=60 and l_runinterval>5*l_taskinterval*60) or (l_taskinterval>60 and l_runinterval-l_taskinterval*60>3600) then
             update sys_task set lockzt='1',lastrunnode=s_lastrunnode,lastruntime=sysdate where taskid=s_taskid;
             Result:= 'true';
           end if;
         end if;

       end if;
     exception when others then
       null;
     end;
     commit;


end p_get_tasklock;

/
