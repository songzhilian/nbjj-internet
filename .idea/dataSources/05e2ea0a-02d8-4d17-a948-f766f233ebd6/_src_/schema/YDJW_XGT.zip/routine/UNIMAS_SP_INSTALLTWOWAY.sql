CREATE PROCEDURE UNIMAS_SP_INSTALLTWOWAY (
  indbSchema in  varchar2,
  intodoTbl in varchar2,
  intblName in  varchar2,
  act     in varchar2,
  user    in varchar2
)
is
strSQL varchar2(4000); --要执行的SQL语句
strPKs varchar2(2550); --主关键字字符串，多个关键字名称之间用逗号分隔
strPKTypes varchar2(2550); --主关键字类型字符串，多个关键字类型之间用逗号分隔
strSelect varchar2(3000);  ----更新行的数据选择
strUpdatingPK varchar2(2000); --更新主键
intLoop int;
strSelDel varchar(3000);
dbSchema varchar2(30);
tblName varchar2(30);
todoTbl varchar2(30);
HashValue varchar2(25);
strHostname varchar(256);
strtempHostname varchar(256);
hostlength number;
v_ind number;
cursor curpks is select a.column_name ,a.data_type from sys.user_tab_cols  a inner join sys.user_cons_columns b on a.table_name=b.table_name and a.column_name=b.column_name and b.owner=UPPER(indbSchema) inner join sys.user_constraints c on b.owner=b.owner and b.constraint_name=c.constraint_name and c.constraint_type='P' where c.table_name=intblName order by a.column_name asc;
begin
  dbSchema:=UPPER(indbSchema);
  tblName:=intblName;
  todoTbl:=UPPER(intodoTbl);
  select machine into strHostname from v$session where audsid = userenv('sessionid') and rownum = 1;
  --strHostname
--  DBMS_OUTPUT.PUT_LINE(strHostname);
  v_ind:=INSTR(strHostname,'\');
  if (v_ind>0) then
    begin
      SELECT length(strHostname) INTO hostlength FROM dual;
      SELECT SUBSTR(strHostname, 0, hostlength-1) INTO strHostname FROM DUAL;
    end;
  end if;
--  DBMS_OUTPUT.PUT_LINE(v_ind);
  select replace(strHostname, '\', '\\') into strHostname from dual;
  if(strHostname is null) then  strHostname:='null'; end if;
  select to_char(dbms_utility.get_hash_value(dbSchema||tblName||todoTbl,0,1000000))  into HashValue from dual;
  intLoop:=0;
  strSelect:='select (';
  strSelDel:='select (';
  for c_curpk in curpks loop
    if intLoop=0 then
      begin
        strPKs:=c_curpk.column_name;
        strPKTypes:=c_curpk.data_type;
         if c_curpk.data_type = 'DATE' then
             strSelect:=strSelect||'replace(replace(replace(TO_CHAR(:new.'||c_curpk.column_name ||',''YYYY-MM-DD hh24:mi:ss''),''\'',''\\''),'','',''\,''),'';'',''\;'')';
             strSelDel:=strSelDel||'replace(replace(replace(TO_CHAR(:old.'||c_curpk.column_name ||',''YYYY-MM-DD hh24:mi:ss''),''\'',''\\''),'','',''\,''),'';'',''\;'')';
         elsif  c_curpk.data_type = 'TIMESTAMP(6)' then
             strSelect:=strSelect||'replace(replace(replace(TO_CHAR(:new.'||c_curpk.column_name ||',''YYYY-MM-DD hh24:mi:ss.ff6''),''\'',''\\''),'','',''\,''),'';'',''\;'')';
             strSelDel:=strSelDel||'replace(replace(replace(TO_CHAR(:old.'||c_curpk.column_name ||',''YYYY-MM-DD hh24:mi:ss.ff6''),''\'',''\\''),'','',''\,''),'';'',''\;'')';
        else
            strSelect:=strSelect||'replace(replace(replace(replace(TO_CHAR(:new.'||c_curpk.column_name ||'),''\'',''\\''),'','',''\,''),'';'',''\;''),'''''''','''''''''''')';
            strSelDel:=strSelDel||'replace(replace(replace(replace(TO_CHAR(:old.'||c_curpk.column_name ||'),''\'',''\\''),'','',''\,''),'';'',''\;''),'''''''','''''''''''')';
        end if;
        strUpdatingPK:='updating('''||c_curpk.column_name||''')';
      end;
    else
      begin
        strPKs:=strPKs||','||c_curpk.column_name;
        strPKTypes:=strPKTypes||','||c_curpk.data_type;
         if c_curpk.data_type = 'DATE' then
             strSelect:=strSelect||'||'',''||replace(replace(replace(TO_CHAR(:new.'||c_curpk.column_name ||',''YYYY-MM-DD hh24:mi:ss''),''\'',''\\''),'','',''\,''),'';'',''\;'')';
             strSelDel:=strSelDel||'||'',''||replace(replace(replace(TO_CHAR(:old.'||c_curpk.column_name ||',''YYYY-MM-DD hh24:mi:ss''),''\'',''\\''),'','',''\,''),'';'',''\;'')';
         elsif  c_curpk.data_type = 'TIMESTAMP(6)' then
             strSelect:=strSelect||'||'',''||replace(replace(replace(TO_CHAR(:new.'||c_curpk.column_name ||',''YYYY-MM-DD hh24:mi:ss.ff6''),''\'',''\\''),'','',''\,''),'';'',''\;'')';
             strSelDel:=strSelDel||'||'',''||replace(replace(replace(TO_CHAR(:old.'||c_curpk.column_name ||',''YYYY-MM-DD hh24:mi:ss.ff6''),''\'',''\\''),'','',''\,''),'';'',''\;'')';
        else
            strSelect:=strSelect||'||'',''||replace(replace(replace(replace(TO_CHAR(:new.'||c_curpk.column_name ||'),''\'',''\\''),'','',''\,''),'';'',''\;''),'''''''','''''''''''')';
            strSelDel:=strSelDel||'||'',''||replace(replace(replace(replace(TO_CHAR(:old.'||c_curpk.column_name ||'),''\'',''\\''),'','',''\,''),'';'',''\;''),'''''''','''''''''''')';
        end if;
        strUpdatingPK:=strUpdatingPK||' or '||'updating('''||c_curpk.column_name||''')';
       end;
     end if;
     intLoop:=intLoop+1;
  end loop;
  strSelect:=strSelect||' ) INTO newStrVals from dual; ';
  strSelDel:=  strSelDel||' ) INTO oldStrVals from dual; ';

  if(INSTR(act,'i')>0 or INSTR(act,'I')>0) then
  strSQL:='create or replace trigger '||dbSchema||'.UMTS_TODO'||HashValue||'I
    after insert
    on '||dbSchema||'."'||tblName ||'"
    FOR EACH ROW
    DECLARE
      newStrVals    varchar2(2550);
      strInsert  varchar2(4000);
      v_osuser varchar2(30);
      v_machine varchar2(50);
      v_ip_addr varchar2(20);
      v_ind     number;
      hostlength number;
    begin
      select osuser,sys_context(''userenv'',''ip_address''),machine into v_osuser,v_ip_addr,v_machine from v$session where audsid = userenv(''sessionid'')  and rownum = 1;
--      DBMS_OUTPUT.PUT_LINE(v_machine);
      v_ind:=INSTR(v_machine,''\'');
      if (v_ind>0) then
       begin
         SELECT length(v_machine) INTO hostlength FROM dual;
         SELECT SUBSTR(v_machine, 0, hostlength-1) INTO v_machine FROM DUAL;
       end;
      end if;
      select replace(v_machine,''\'',''\\'') into v_machine from dual;
      if (v_machine<>'''||strHostname||''' or v_machine is null) then
--        begin
--          DBMS_OUTPUT.PUT_LINE(''it was inserted by myself'');
--        end;
--      else
        begin
      '||strSelect||'
      strInsert:=''insert into '||dbSchema||'.'||todoTbl||'(seqno,dbname,tblname,pks,mark,act) values(YDJW_XGT.UNIMAS_SQ_FORTBLTODO.nextval,'''''||dbSchema||''''','''''||tblName||''''','''''||strPKs||';'||strPKTypes||';''||newStrVals||'';'''',1,''''i'''')'';
      --DBMS_OUTPUT.PUT_LINE(strInsert);
      execute immediate strInsert;
        end;
      end if;
    end;';
  --insert into tbldebug values(strSql,DEBUGSEQNO.nextval);
  execute immediate strSQL;
  end if;

  if(INSTR(act,'u')>0 or INSTR(act,'U')>0) then
  strSQL:='create or replace trigger '||dbSchema||'.UMTS_TODO'||HashValue||'U
    after update
    on '||dbSchema||'."'||tblName ||'"
    FOR EACH ROW
    DECLARE
      oldStrVals    varchar2(2550);
      newStrVals    varchar2(2550);
      strInsert  varchar2(4000);
      v_osuser varchar2(30);
      v_machine varchar2(50);
      v_ip_addr varchar2(20);
      v_ind     number;
      hostlength number;
    begin
      select osuser,sys_context(''userenv'',''ip_address''),machine into v_osuser,v_ip_addr,v_machine from v$session where audsid = userenv(''sessionid'')   and rownum = 1;
--      DBMS_OUTPUT.PUT_LINE(v_machine);
      v_ind:=INSTR(v_machine,''\'');
      if (v_ind>0) then
       begin
         SELECT length(v_machine) INTO hostlength FROM dual;
         SELECT SUBSTR(v_machine, 0, hostlength-1) INTO v_machine FROM DUAL;
       end;
      end if;
      select replace(v_machine,''\'',''\\'') into v_machine from dual;
      if (v_machine<>'''||strHostname||''' or v_machine is null) then
--        begin
--          DBMS_OUTPUT.PUT_LINE(''it was updated by myself'');
--        end;
--      else
        begin
        '||strSeldel||'
        '||strSelect||'
      if '||strUpdatingPK||' then
        begin
          strInsert:=''insert into '||dbSchema||'.'||todoTbl||'(seqno,dbname,tblname,pks,mark,act) values(YDJW_XGT.UNIMAS_SQ_FORTBLTODO.nextval,'''''||dbSchema||''''','''''||tblName||''''','''''||strPKs||';'||strPKTypes||';''||oldStrVals||'';'''',1,''''d'''')'';
          execute immediate strInsert;
          strInsert:=''insert into '||dbSchema||'.'||todoTbl||'(seqno,dbname,tblname,pks,mark,act) values(YDJW_XGT.UNIMAS_SQ_FORTBLTODO.nextval,'''''||dbSchema||''''','''''||tblName||''''','''''||strPKs||';'||strPKTypes||';''||newStrVals||'';'''',1,''''i'''')'';
          execute immediate strInsert;
        end;
      else
        begin
          strInsert:=''insert into '||dbSchema||'.'||todoTbl||'(seqno,dbname,tblname,pks,mark,act) values(YDJW_XGT.UNIMAS_SQ_FORTBLTODO.nextval,'''''||dbSchema||''''','''''||tblName||''''','''''||strPKs||';'||strPKTypes||';''||newStrVals||'';'''',1,''''u'''')'';
          execute immediate strInsert;
        end;
      end if;
        end;
      end if;
    end;';
  --insert into tbldebug values(strSql,DEBUGSEQNO.nextval);
  execute immediate strSQL;
  end if;

  if(INSTR(act,'d')>0 or INSTR(act,'D')>0) then
    strSQL:='create or replace trigger '||dbSchema||'.UMTS_TODO'||HashValue||'D
    after delete
    on '||dbSchema||'."'||tblName ||'"
    FOR EACH ROW
    DECLARE
    oldStrVals    varchar2(2550);
    strInsert  varchar2(4000);
    v_osuser varchar2(30);
    v_machine varchar2(50);
    v_ip_addr varchar2(20);
    v_ind     number;
    hostlength number;
    begin
      select osuser,sys_context(''userenv'',''ip_address''),machine into v_osuser,v_ip_addr,v_machine from v$session where audsid = userenv(''sessionid'')    and rownum = 1;
--      DBMS_OUTPUT.PUT_LINE(v_machine);
      v_ind:=INSTR(v_machine,''\'');
      if (v_ind>0) then
       begin
         SELECT length(v_machine) INTO hostlength FROM dual;
         SELECT SUBSTR(v_machine, 0, hostlength-1) INTO v_machine FROM DUAL;
       end;
      end if;
      select replace(v_machine,''\'',''\\'') into v_machine from dual;
      if (v_machine<>'''||strHostname||''' or v_machine is null) then
--        begin
--          DBMS_OUTPUT.PUT_LINE(''it was deleted by myself'');
--        end;
--      else
        begin
      '||strSelDel||'
      strInsert:=''insert into '||dbSchema||'.'||todoTbl||'(seqno,dbname,tblname,pks,mark,act) values(YDJW_XGT.UNIMAS_SQ_FORTBLTODO.nextval,'''''||dbSchema||''''','''''||tblName||''''','''''||strPKs||';'||strPKTypes||';''||oldStrVals||'';'''',1,''''d'''')'';
      --DBMS_OUTPUT.PUT_LINE(strInsert);
      execute immediate strInsert;
        end;
      end if;
    end;';
    execute immediate strSQL;
  end if;

  exception
      when others then
      	raise_application_error(-20000, 'Unknown Exception Raised: '||sqlcode||' '||sqlerrm);
      return;
end;

/
