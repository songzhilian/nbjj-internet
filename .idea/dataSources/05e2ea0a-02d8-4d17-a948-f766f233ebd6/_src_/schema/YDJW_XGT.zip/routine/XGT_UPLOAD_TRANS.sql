CREATE procedure xgt_upload_trans is
    v_exists           number;

    v_fileid            number(22);
    v_data              blob;
    v_ins              varchar2(1);
    v_error            varchar2(128);

    cursor cur1 is select fileid, data
       from file_upload_data_fxc;



  begin

    open cur1;


    loop
      fetch cur1 into v_fileid, v_data;

      exit when cur1%notfound;
      v_ins:='0';--0锟斤拷锟斤拷锟斤拷
      begin
        select count(1)   into v_exists  from xgt_file_upload_data_fxc where fileid=v_fileid;
        if v_exists =  0  then

          v_ins:='1';
        end if;
      exception when others then
        v_ins:='0';
      end;
      if v_ins='1' then
        begin

            insert into xgt_file_upload_data_fxc
              (fileid, data )
              values
              (v_fileid, v_data);
            commit;

          --end if ;
        exception when others then
           v_error:=sqlerrm;
           DBMS_OUTPUT.put_line(v_error);
        end;
      end if;
    end loop;




    close cur1;


    commit;
  end xgt_upload_trans ;

/
