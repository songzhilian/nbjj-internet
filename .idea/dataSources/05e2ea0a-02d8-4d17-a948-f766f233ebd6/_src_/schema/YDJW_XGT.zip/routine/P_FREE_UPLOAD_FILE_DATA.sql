CREATE procedure p_free_upload_file_data
as

begin
  if to_number(to_char(sysdate,'hh24'))<6 then
    delete from xgt_file_upload_data_fxc where lrsj < sysdate- 15 and rownum < 50;
    commit;
  end if;
end p_free_upload_file_data;

/
