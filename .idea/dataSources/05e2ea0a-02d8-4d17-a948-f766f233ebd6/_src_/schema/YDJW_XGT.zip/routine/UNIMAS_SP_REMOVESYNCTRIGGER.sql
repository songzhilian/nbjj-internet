CREATE PROCEDURE UNIMAS_SP_REMOVESYNCTRIGGER
 (
 indbSchema in varchar2,
 inTodoTbl in varchar2,
 inTblName in varchar2 default ' ',
 act in varchar2 default ' '
)
as
strSql varchar2(500);
HashValue varchar2(25);
dbSchema varchar2(30);
tblName varchar2(30);
todoTbl varchar2(30);
strTriName varchar2(255);
cursor curtrigger is select trigger_name from sys.user_triggers where table_owner=UPPER(dbSchema) and trigger_name like 'UMTS_TODO'||'%';
begin

  dbSchema:=UPPER(indbSchema);
  tblName:=inTblName;
  todoTbl:=UPPER(inTodoTbl);
  FOR cur in curtrigger  loop
     strTriName:=cur.trigger_name;

     if(INSTR(act,'I')>0 or INSTR(act,'i')>0) then
        begin
        select to_char(dbms_utility.get_hash_value(dbSchema||tblName||todoTbl,0,1000000))  into HashValue from dual;
        if(strTriName='UMTS_TODO'||HashValue||'I') then
            begin
                  strSql:='drop trigger '||dbSchema||'.'||strTriName;
                  --insert into tbldebug values(strSql,DEBUGSEQNO.nextval);
                  execute immediate strSql;
              end ;
         end if;
         end;
     end if;

     if(INSTR(act,'U')>0 or INSTR(act,'u')>0) then
        begin
        select to_char(dbms_utility.get_hash_value(dbSchema||tblName||todoTbl,0,1000000))  into HashValue from dual;
        if(strTriName='UMTS_TODO'||HashValue||'U') then
            begin
                  strSql:='drop trigger '||dbSchema||'.'||strTriName;
                  --insert into tbldebug values(strSql,DEBUGSEQNO.nextval);
                  execute immediate strSql;
              end ;
         end if;
         end;
     end if;

     if(INSTR(act,'D')>0 or INSTR(act,'d')>0) then
       begin
        select to_char(dbms_utility.get_hash_value(dbSchema||tblName||todoTbl,0,1000000))  into HashValue from dual;
        if(strTriName='UMTS_TODO'||HashValue||'D') then
            begin
                  strSql:='drop trigger '||dbSchema||'.'||strTriName;
                  --insert into tbldebug values(strSql,DEBUGSEQNO.nextval);
                  execute immediate strSql;
              end;
         end if;
         end;
      end if;
      if(act is NUll or act='') then
             begin
                  strSql:='drop trigger '||dbSchema||'.'||strTriName;
                  --insert into tbldebug values(strSql,DEBUGSEQNO.nextval);
                  execute immediate strSql;
              end;
      end if;
      --insert into tbldebug values(strSql,DEBUGSEQNO.nextval);
  end loop;

  exception
  when others then
  	raise_application_error(-20000, 'Unknown Exception Raised: '||sqlcode||' '||sqlerrm);
  return;

end;

/
