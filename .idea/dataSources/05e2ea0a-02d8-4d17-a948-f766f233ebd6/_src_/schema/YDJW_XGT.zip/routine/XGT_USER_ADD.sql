CREATE procedure xgt_user_add is

    v_yhdm           varchar2(32);
    v_bmdm           varchar2(12);
    v_xm             varchar2(32);
    v_sfzmhm         varchar2(18);
    v_count          number;

    cursor curl is select yhdm,xm, sfzmhm, bmdm from xgt_acl_user_tmp ;

  begin

    open curl;

    loop
        fetch curl into v_yhdm, v_xm, v_sfzmhm, v_bmdm;

        exit when curl%notfound;

        select count(1) into  v_count from xgt_acl_user where yhdm=v_yhdm;

        if v_count = 0 then
            begin

               insert into xgt_acl_user
                (yhdm, xm, sfzmhm, bmdm, mm, sfmj,sfbd, zt, gxsj )
                values
                (v_yhdm, v_xm, v_sfzmhm, v_bmdm, '733D7BE2196FF70EFAF6913FC8BDCABF','4', '0','1',sysdate );

                insert into acl_user_privilege
                (id, yhdm, bmdm, privilegeid, privilegetype)
                values
                (seq_acl_user_privilege.nextval, v_yhdm, v_bmdm, 21, '1' );
            end;

        end if;


    end loop;

    close curl;
    commit;

  end xgt_user_add ;

/
