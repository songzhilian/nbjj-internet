CREATE procedure p_xgt_check_upload(v_ywlx in varchar2, v_ywlsh in number, v_filename in varchar2,v_result out varchar2 ) is
v_checklsh char(1);

v_count    number;
begin
  v_result:='1';--1锟斤拷锟斤拷锟斤拷5-锟斤拷锟斤拷锟斤拷6-锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
  --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
  v_checklsh:='1';
  if v_ywlx='3' then
    select count(1) into v_count from xgt_vio_surveil_in where lsh=v_ywlsh;
    if v_count=0 then
      v_checklsh:='0';
    end if;
  end if;

  if v_checklsh='0' then
    v_result:='6';--锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷6
  else
     --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
      v_count:=0;
      select count(1) into v_count from xgt_file_upload t1,xgt_file_upload_data_fxc t2 where ywlx=v_ywlx and ywlsh=v_ywlsh and filename=v_filename and zt='1'
        and t1.fileid=t2.fileid and t2.data is not null;
      if v_count>0 then
        v_result:='5';--锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷5
      end if;

       select count(1) into v_count from xgt_file_upload t1,xgt_file_upload_data_qt t3 where ywlx=v_ywlx and ywlsh=v_ywlsh and filename=v_filename and zt='1'
        and t1.fileid=t3.fileid and t3.data is not null;

       if v_count>0 then
        v_result:='5';--锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷5
      end if;

  end if;

end p_xgt_check_upload;

/
