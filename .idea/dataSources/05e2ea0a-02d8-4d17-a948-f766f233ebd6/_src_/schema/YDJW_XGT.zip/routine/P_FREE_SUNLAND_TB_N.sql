CREATE procedure p_free_sunland_tb_n
as
begin
loop
    delete from sunland_tb_n  where bdrq <to_date(sysdate-12);
    exit when SQL%ROWCOUNT=0;
commit;
end loop;
exception
    when others then
    rollback;
return;
end;

/
