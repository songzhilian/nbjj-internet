CREATE package filepkg2 is

  procedure p_clean_fileblock;
  procedure p_clean_syslog;
  procedure p_clean_syslogtxt;
  procedure p_clean_heartbeat;
  procedure p_clean_filedata;
  procedure p_clean_all;

end filepkg2;

/
