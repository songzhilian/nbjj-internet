CREATE package body filepkg2 is
  --清理block
  procedure p_clean_fileblock is
    v_tindex              varchar2(32);
    v_count               number;
    rec_block             file_upload_block_01%rowtype;
    v_index               number:=1;
    type ref_cursor is ref cursor;
    cur1 ref_cursor;
    rec_fileconfig         file_upload_config%rowtype;
    begin
       select count(*) into v_count from file_upload_config where tname='FileUploadBlock' and zt='0';
       if v_count > 0 then
          select * into rec_fileconfig from file_upload_config where tname='FileUploadBlock' and zt='0';
          if trunc(sysdate)-trunc(rec_fileconfig.jssj)>4 then
            if rec_fileconfig.tindex = '01' then
                open cur1 for select a.* from file_upload_block_01 a where exists(select null from xgt_file_upload b where zt='0' and ywlx='3'
                and a.fileid=b.fileid);
            end if;
            if rec_fileconfig.tindex = '02' then
                open cur1 for select a.* from file_upload_block_02 a where exists(select null from xgt_file_upload b where zt='0' and ywlx='3'
                and a.fileid=b.fileid);
            end if;
               loop
               fetch cur1 into rec_block;
               exit when cur1%notfound;
                 begin
                    insert into file_upload_block_99(blockid, fileid, blockidx, blocksize, data)values
                    (rec_block.blockid,rec_block.fileid,rec_block.blockidx,rec_block.blocksize,rec_block.data);
                    if mod(v_index,1000)=0 then
                       commit;
                    end if ;
                    v_index:=v_index+1;
                    exception when others then
                        null;
                  end;
                 end loop;
               close cur1;
               commit;
               execute immediate 'truncate table file_upload_block_'||rec_fileconfig.tindex;
           end if;
       end if;
    exception when others then
    null;
  end p_clean_fileblock;

  --清理sys_log_data
  procedure p_clean_syslog is
    i_days              number;
    v_tindex            varchar2(32);
  begin
    select trunc(sysdate)-trunc(jssj),tindex into i_days,v_tindex from file_upload_config
     where tname='SysLogData' and zt='0';

    if i_days >= 4 then --保留7天的日志
       --删除zt=0的另外个日志表的数据
       if v_tindex = '01' then
       --删除02的日志表
          execute immediate 'truncate table sys_log_data_01';
       end if;

       if v_tindex = '02' then
       --删除01的日志表
          execute immediate 'truncate table sys_log_data_02';
       end if;
    end if;
  exception when others then
    null;
  end p_clean_syslog;

  procedure p_clean_syslogtxt is
  begin
    for i in 15..32 loop
      delete from sys_log where qqsj>=trunc(sysdate)-(i+1) and qqsj<trunc(sysdate)-i and jkid='uploadFileBlockXj';
      commit;
    end loop;
  exception when others then
    null;
  end p_clean_syslogtxt;

  procedure p_clean_heartbeat is
  begin
    for i in 30..35 loop
      delete from sys_heartbeat where qqsj>=trunc(sysdate)-(i+1) and qqsj<trunc(sysdate)-i;
      commit;
    end loop;
  exception when others then
    null;
  end p_clean_heartbeat;

  procedure p_clean_filedata is
    v_index             number;
  begin
    v_index:=0;
    for c in(select * from xgt_file_upload where wcsj>trunc(sysdate-32) and wcsj<trunc(sysdate-20)) loop

      delete from xgt_file_upload_data_fxc where fileid=c.fileid;
      v_index:=v_index+1;
      if mod(v_index,100)=0 then
        commit;
      end if;
    end loop;
    commit;
  exception when others then
    null;
  end p_clean_filedata;

  procedure p_clean_all is
  begin
    p_clean_syslog;--清理sys_log_data
    p_clean_syslogtxt;--清理sys_log表中uploadfileblock接口调用的日志文本记录
    p_clean_heartbeat;
    p_clean_fileblock;--清理file_upload_block，有用的数据移至block_99
    p_clean_filedata;--清理合成的图片，保留一定的时间

  end p_clean_all;

end filepkg2;

/
