CREATE package body ws is
  --1jy,3-qz;6-wftz,7-wt,fxccl-8
  function f_get_wsjyw(wsbh in varchar2) return varchar2 is
    wsjyw    varchar2(1);
  begin
    wsjyw:=to_char(mod(to_number(substr(wsbh,8)),7));
    return(wsjyw);
  end f_get_wsjyw;

  function f_get_xzqhws(v_bmdm in varchar2, v_wslb in varchar2) return varchar2 is
    v_ret                      varchar2(12);
    begin

      if substr(v_bmdm,1,6)='330302' then
        v_ret:=substr(v_bmdm,1,8);
      --elsif substr(v_bmdm,1,8)='33030050' and v_wslb='8' then
      --  v_ret:=substr(v_bmdm,1,8);
      else
        v_ret:=substr(v_bmdm,1,6);
      end if;
      return(v_ret);
   exception when others then
      null;

 end f_get_xzqhws;

  --锟斤拷锟斤拷锟斤拷锟斤拷
  /*
  procedure p_get_wsbh(s_wslb  in varchar2, i_wssl  in number,  s_bmdm  in varchar2, s_yhdm  in varchar2, s_wsbhs out varchar2) is
    s_wsbh varchar2(20);
    s_xzqh varchar2(12);
    type type_pda_wsbh is table of pda_wsbh.wsbh%type;
    v_pda_wsbh_row type_pda_wsbh;
    cursor c1 is
      select wsbh
        from (select wsbh from pda_wsbh  where glxzqh =s_xzqh  and wslb = s_wslb  and lyzt = '0' order by wsbh )
       where rownum <= i_wssl;
  begin
    select f_get_xzqhws(s_bmdm, s_wslb) into s_xzqh from dual;
    select wsbh bulk collect into v_pda_wsbh_row from pda_wsbh
      where glxzqh = s_xzqh and wslb=s_wslb and lyzt='0' for update;
    open c1;
    loop
      fetch c1
        into s_wsbh;
      exit when c1%notfound;
      s_wsbhs := s_wsbhs || '@' || s_wsbh||f_get_wsjyw(s_wsbh);
      update pda_wsbh set lyzt = '1',lysj=sysdate, yhdm=s_yhdm where wsbh = s_wsbh;
    end loop;
    close c1;
    commit;
  end p_get_wsbh;
  */
   --文书领用
  procedure p_get_wsbh(s_wslb  in varchar2, i_wssl  in number,  s_bmdm  in varchar2, s_yhdm  in varchar2, s_wsbhs out varchar2) is
    s_wsbh varchar2(20);
    s_xzqh varchar2(12);
      begin
       if s_wslb in('b','B') then
          for i in 1..i_wssl
          loop
            s_wsbh:=ws.f_get_xgtaqtkbh(s_bmdm,s_yhdm);
            s_wsbhs := s_wsbhs || '@' || s_wsbh;
          end loop;

        end if;
      exception when others then
        dbms_output.put_line(sqlcode || '::' || substr(sqlerrm,1,200));
        s_wsbhs:='';
        rollback;
  end p_get_wsbh;

  procedure p_get_wsbhNew(s_wslb  in varchar2, i_wssl  in number,  s_bmdm  in varchar2, s_yhdm  in varchar2, s_pdaid  in varchar2, s_wsbhs out varchar2) is
    s_wsbh varchar2(20);
    s_xzqh varchar2(12);
      begin
        if s_wslb in('A1','a1') then
          for i in 1..i_wssl
          loop
            s_wsbh:=ws.f_get_xgt_acd_sgbh(s_bmdm);
            s_wsbhs := s_wsbhs || '@' || s_wsbh;
            insert into pda_wsbh(wsbh,wslb,yhdm,glbm,imei,lyzt,lysj,syzt,sysj)
            values(s_wsbh,s_wslb,s_yhdm,s_bmdm,s_pdaid,'1',sysdate,0,null);
          end loop;
          commit;
        elsif s_wslb='7' then
          for i in 1..i_wssl
          loop
            s_wsbh:=ws.f_get_xgt_vio_surveil_wsbh(s_bmdm);
            s_wsbhs := s_wsbhs || '@' || s_wsbh;
            insert into pda_wsbh(wsbh,wslb,yhdm,glbm,imei,lyzt,lysj,syzt,sysj)
            values(s_wsbh,s_wslb,s_yhdm,s_bmdm,s_pdaid,'1',sysdate,0,null);
          end loop;
          commit;
        elsif s_wslb in('b','B') then
          for i in 1..i_wssl
          loop
            s_wsbh:=ws.f_get_xgtaqtkbh(s_bmdm,s_yhdm);
            s_wsbhs := s_wsbhs || '@' || s_wsbh;
          end loop;

        end if;
      exception when others then
        dbms_output.put_line(sqlcode || '::' || substr(sqlerrm,1,200));
        s_wsbhs:='';
        rollback;
  end p_get_wsbhNew;

  --锟斤拷锟斤拷锟斤拷锟斤拷
  procedure p_use_wsbh(s_wslb  in varchar2, s_wsbh in varchar2) is
  begin
    update pda_wsbh set syzt = '1',sysj=sysdate where wsbh = s_wsbh and wslb=s_wslb;

    commit;
  end p_use_wsbh;

  --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
  procedure p_init_wsbh(s_wslb in varchar2, s_glbm in varchar2, i_ks in number, i_js in number) is
    s_wsbh                 varchar2(20);
    s_wslbnew              varchar2(1);
  begin
    s_wslbnew:=s_wslb;
    if s_wslb='8' then
       s_wslbnew:='1';
    end if;

    for i in i_ks .. i_js loop
      if s_wslb='9' then
         s_wsbh := 'FY'||substr(s_glbm, 1, 6) || s_wslbnew || lpad(i, 8, '0');
      else
         s_wsbh := substr(s_glbm, 1, 6) || s_wslbnew || lpad(i, 8, '0');
      end if;
      insert into pda_wsbh
        (wsbh, wslb, lyzt, syzt, sqsj, glxzqh, glbm)
      values
        (s_wsbh, s_wslb, '0', '0', sysdate, f_get_xzqhws(s_glbm,s_wslb), s_glbm);
      if mod(i, 50000) = 0 then
        commit;
      end if;
    end loop;
    commit;

  end p_init_wsbh;
  /**获取一个虚的安全头盔编号**/
      function f_get_xgtaqtkbh(v_bmdm in varchar2,v_yhdm in varchar2) return varchar2 is
        Result varchar2(16);
      begin
          select substr(v_bmdm,1,6)||'97'||lpad(seq_xgtvioaqtk_aqtkbh.nextval,7,'0') into Result from dual;

        return(Result);
      end f_get_xgtaqtkbh;

     --生成协警事故编号
  function f_get_xgt_acd_sgbh(v_bmdm in varchar2) return varchar2 is
    Result varchar2(20);
    begin
      select substr(v_bmdm,1,6)||'599'||lpad(seq_xgt_acd_wsbh.nextval,9,'0') into Result from dual;
      return Result;
     end f_get_xgt_acd_sgbh;

     --生成协警违停编号
  function f_get_xgt_vio_surveil_wsbh(v_bmdm in varchar2) return varchar2 is
    Result varchar2(24);
    begin
      select substr(v_bmdm,1,6)||lpad(seq_xgt_vio_surveil_wsbh.nextval,10,'0') into Result from dual;
      return Result;
     end f_get_xgt_vio_surveil_wsbh;


end ws;

/
