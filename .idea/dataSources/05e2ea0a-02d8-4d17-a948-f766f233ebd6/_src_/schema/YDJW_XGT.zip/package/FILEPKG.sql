CREATE package filepkg is

  procedure p_get_tablename(v_tname in varchar2, v_cur_tname out varchar2) ;
  procedure p_move_block_99;
  procedure p_clean_block;
  procedure p_clean_syslog;


end filepkg;

/
