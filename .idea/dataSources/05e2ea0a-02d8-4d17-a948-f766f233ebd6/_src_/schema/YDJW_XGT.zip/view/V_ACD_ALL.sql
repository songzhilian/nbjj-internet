CREATE VIEW V_ACD_ALL AS select 'A'||lsh lsh,'1' sglx/*简易事故*/,wsbh sgbh,sgfssj,sgdd,tq,sgss from acd_dutysimple t1 where 1=1
union all
select 'B'||lsh lsh,'2' sglx/*简易事故*/,sgbh,sgfssj,sgdd,tq,sgxt sgss from xgt_acd_zxxs t1 where 1=1
/
