CREATE VIEW V_ACL_USER_PRIVILEGE AS select p.id,p.yhdm,p.bmdm,p.privilegeid,p.privilegetype,m.menuid menuid,
m.name,m.url,m.parentid,m.menutype,m.zt,m.px
from acl_user_privilege p, acl_role_menu r, acl_menu m
where p.privilegetype='1' and p.privilegeid=r.roleid and m.menuid=r.menuid
union all
select p.id,p.yhdm,p.bmdm,p.privilegeid,p.privilegetype,m.menuid menuid,
m.name,m.url,m.parentid,m.menutype,m.zt,m.px
from acl_user_privilege p, acl_menu m
where p.privilegetype='2' and m.menuid=p.privilegeid
/
