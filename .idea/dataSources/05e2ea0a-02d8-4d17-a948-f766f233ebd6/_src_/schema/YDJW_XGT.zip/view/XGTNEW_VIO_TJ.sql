CREATE VIEW XGTNEW_VIO_TJ AS select t0.xzqh,t0.xm, t0.yhdm, nvl(sgcl,0) sgcl, nvl(wt,0) wt,nvl(sgwf,0) sgwf  from
        (select substr(bmdm,1,6) xzqh, yhdm,xm from xgt_acl_user  where yhdm in(select yhdm from xgtnew_acl_user) and yhdm<>'030493' ) t0
         left join (select cjmj, count(1) as sgcl from xgt_acd_zxxs group by cjmj) t1  on t0.yhdm =t1.cjmj
         left join (select yhdm, count(1) as wt from xgt_vio_surveil_in where ywzl='1' and yl3='2' group by yhdm) t2  on t0.yhdm =t2.yhdm
         left join (select yhdm, count(1) as sgwf from xgt_vio_surveil_in where ywzl='5' and yl3='2' group by yhdm) t3  on t0.yhdm =t3.yhdm
         order by t0.xzqh
/
