CREATE VIEW V_ACD_ALLHUMAN AS select 'A'||lsh lsh,rybh,sfzmhm,xm,xb,nl,zz,dh,shcd,wfxw1,wfxw2,wfxw3,jtfs,dabh,jl,zjcx,cclzrq,hphm,hpzl,fdjh,clsbdh,clpp,clxh,csys,cllx,jdcsyr,sgzr,bxgs,bxpzh,bx bxgsid from acd_dutysimplehuman t1 where 1=1
union all
select 'B'||lsh lsh,rybh,sfzmhm,xm,xb,nl,'' zz,dh,shcd,'' wfxw1,'' wfxw2,'' wfxw3,jtfs,dabh,0 jl,zjcx,cclzrq,hphm,hpzl,'' fdjh,'' clsbdh,clpp,'' clxh,csys,cllx,jdcsyr,sgzr,bxgs,bxpzh,yl2 bxgsid from xgt_acd_zxxshuman t1 where 1=1
/
