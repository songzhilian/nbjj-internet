CREATE VIEW V_XGT_ACL_USER AS select yhdm,xm,bmdm from xgt_acl_user
/
