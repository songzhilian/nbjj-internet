CREATE type "GZL_ROWTYPE" AS
OBJECT(xmdl varchar2(10), xmdlmc varchar2(32), xmxl varchar2(10), xmxlmc varchar2(32), sl number)

/
